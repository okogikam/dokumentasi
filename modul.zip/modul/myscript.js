class gDrive{
    constructor (dom){
        this.dom = dom;
        this.url = "https://script.google.com/macros/s/AKfycbzP2X2VAW7xhplAwIfaoKObI2_QrgXKD7WjJYC4W3yq9GythYC-kfG4p9QxUy3SyQXz/exec";
    }
    async connect(){
        // if(!this.id) return;
        let requist = await fetch(this.url);
        let hasil = await requist.json();
        return hasil;
    }

    async makeTable(){
        let data = await this.connect();
        let table = document.createElement('table');
        table.setAttribute('class','table table-striped');
        let thead,tbody;
        thead = document.createElement("thead");
        thead.innerHTML = `<tr>
        <th class="text-center">Nama File</th>
        <th width="100" class="text-center">Update terakhir</th>
        <th width="100" class="text-center">Opsi</th>
        </tr>`
       
        tbody = document.createElement("tbody");
        for(let i = 0; i< data.length; i++){
            let tr = document.createElement("tr");
            tr.innerHTML = `
            <td>${data[i]['fileName']}</td>
            <td>${data[i]['lastUpdate'].split("T")[0]}</td>
            <td>
            <a class='btn btn-success' href='${data[i]['url']}' title='view' target='_blank'><i class="fa-regular fa-eye"></i></a>
            <a class='btn btn-info' href='${data[i]['download']}' title='download'><i class="fa-solid fa-download"></i></a>
            </td>
            `
            tbody.appendChild(tr);
        }
        table.appendChild(thead)
        table.appendChild(tbody);
        this.dom.appendChild(table);

        new DataTable(table,{
            destroy: true,
            responsive: true
        })
    }

    init(){
        this.makeTable();
    }
}